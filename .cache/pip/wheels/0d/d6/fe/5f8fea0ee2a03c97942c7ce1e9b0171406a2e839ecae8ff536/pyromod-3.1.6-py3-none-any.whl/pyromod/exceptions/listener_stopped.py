class ListenerStopped(Exception):
    pass
